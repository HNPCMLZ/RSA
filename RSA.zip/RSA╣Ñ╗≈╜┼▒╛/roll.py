#coding:utf-8
 
def crackN(n):
	i = 2
	while i < n :
		if n % i == 0:
			break
		i = i+1
	return i
 
n = 920139713
e = 19
 
p = crackN(n)
q = n / p
 
fn = (p-1)*(q-1)
 
i = 1
d = 0
while (True):
	if (fn * i +1) % e == 0 :
		d = (fn * i +1) / e
		break
	i = i+1
 
print "d:%s" % d
 
c = open("c")
m = ''
for line  in c:
	line = line.replace('\n','')
	m += chr(pow(int(line), d , n))
	print m
