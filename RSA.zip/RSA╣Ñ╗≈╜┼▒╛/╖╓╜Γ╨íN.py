N = 1211809

for i in range(2, N):

    if N % i == 0:

        print (i)