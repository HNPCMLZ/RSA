p = int(input("p:"))
q = int(input("q:"))
e = int(input("e:"))
#print(type(e))
L = (p-1)*(q-1)
i = 0
while True:
    if (1+L*i)%e == 0:
        break
    i+=1
    #print(i)

print("d is %s"%((1+L*i)//e))