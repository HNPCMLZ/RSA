#-*-coding:utf-8-*-
'''
求两个数的最大公约数
算法参考:https://zhidao.baidu.com/question/36550887.html
by:reborn
'''
a=input("input a:")
b=input("input b:")
a=int(a)
b=int(b)
def gys1(a,b):    #辗转相除法(欧几里德算法)
    if a<b:
        a,b=b,a
    while b!=0:
        temp=a%b
        a=b
        b=temp
    return a
def gys2(a,b):    #更相减损法
    while a!=b:
        if a<b:
            a,b=b,a
        temp=a-b
        a=temp
    return a
print ("The gcd(a,b)is:\n",gys2(a,b))