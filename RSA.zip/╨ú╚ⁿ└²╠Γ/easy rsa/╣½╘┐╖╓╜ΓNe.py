from Crypto.PublicKey import RSA
pub=RSA.importKey(open('public.pem').read())
n=int(pub.n)
e=int(pub.e)
print ("N=",n)
print ("e=",e)