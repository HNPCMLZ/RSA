from Crypto.PublicKey import RSA
pub=RSA.importKey(open('pubkey.pem').read())
n=int(pub.n)
e=int(pub.e)
print ("n=",n)
print ("e=",e)


